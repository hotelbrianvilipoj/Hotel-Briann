
import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Upload } from "lucide-react";

const roomsByFloor = {
  "1st Floor": [101, 102, 103, 104, 105],
  "2nd Floor": Array.from({ length: 95 }, (_, i) => 201 + i),
  "3rd Floor": [301, 302, 303, 304, 305],
  "4th Floor": [401, 402, 403, 404, 405],
};

export default function HotelBrianDashboard() {
  const [photos, setPhotos] = useState({});
  const [bookingDetails, setBookingDetails] = useState({});

  const handlePhotoUpload = (room, files) => {
    const selected = Array.from(files).slice(0, 10);
    setPhotos({ ...photos, [room]: selected });
  };

  const handleBooking = (room) => {
    alert(`Booking initiated for room ${room}. Payment gateway coming soon.`);
  };

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold text-center">Hotel Brian - Velipojë</h1>
      <Tabs defaultValue="1st Floor">
        <TabsList className="grid grid-cols-4 gap-2 mb-4">
          {Object.keys(roomsByFloor).map((floor) => (
            <TabsTrigger key={floor} value={floor}>{floor}</TabsTrigger>
          ))}
        </TabsList>
        {Object.entries(roomsByFloor).map(([floor, rooms]) => (
          <TabsContent key={floor} value={floor} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rooms.map((room) => (
              <Card key={room} className="rounded-2xl shadow-md p-4">
                <CardContent className="space-y-4">
                  <h2 className="text-xl font-semibold">Room {room}</h2>
                  <Input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) => handlePhotoUpload(room, e.target.files)}
                  />
                  <div className="grid grid-cols-5 gap-1">
                    {(photos[room] || []).map((file, i) => (
                      <img
                        key={i}
                        src={URL.createObjectURL(file)}
                        alt={`Room ${room} - ${i + 1}`}
                        className="w-full h-20 object-cover rounded"
                      />
                    ))}
                  </div>
                  <Button onClick={() => handleBooking(room)} className="w-full bg-blue-600 text-white">
                    Book & Pay
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
